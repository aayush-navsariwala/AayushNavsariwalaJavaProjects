package create.account;
import java.util.regex.Pattern;
import java.util.Scanner;

public class CreateAccount {

    public static void main(String[] args) {
    {
       
        Scanner kb=new Scanner (System.in);
        String firstname;
        //PROMPT USER
        System.out.println("Enter FirstName:");
        firstname=kb.next();
    
        String surname;
        //PROMPT USER
        System.out.println("Enter Surname");
        surname=kb.next();
       
        String username, password;
        //PROMPT USER
        System.out.println("Enter Username:");
        username=kb.next();
        boolean underscore = username.contains ("_");
    
    if (username.length()<=5 && underscore == true)
            System.out.println("Username successfully captured");
    
    else
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
    
    if (username.length()>5 && underscore==false) {
        System.exit(0); 
    }
        
        //PROMPT USER
        System.out.println("Enter Password:");
        password=kb.next();
        
        Pattern specailCharPatten = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
        Pattern UpperCasePatten = Pattern.compile("[A-Z ]");
        Pattern digitCasePatten = Pattern.compile("[0-9 ]");
        
        boolean flag=true;
        
    if (password.length() < 8) {
        System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
        flag=false;
    }    
    if (!specailCharPatten.matcher(password).find()) { 
        System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
        flag=false;
    }    
    if (!UpperCasePatten.matcher(password).find()) { 
        System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
        flag=false;
    }    
    if (!digitCasePatten.matcher(password).find()) { 
        System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
        flag=false;
    }
    if (flag==false) {
        System.exit(0);
    }
    
    if (flag==true) {
        System.out.println("Password successfully captured");
    }
    {
        Scanner s = new Scanner(System.in);
        String userName;
        String passWord;
        
        //PROMPT USER
        System.out.print("Enter username:");
        userName = s.nextLine();
        
        //PROMPT USER
        System.out.print("Enter password:");
        passWord = s.nextLine();
        
        if(userName.equals(username) && passWord.equals(password))
            
        {
            System.out.println("Successful");
            System.out.println("Welcome "+ firstname+" "+ surname+" it is great to see you");
            System.out.println("Welcome to EasyKanban");
            System.out.println("Add tasks");
            System.out.println("Show report - Coming soon");
            System.out.println("Quit");
        }
        
        else
        {
            System.out.println("Username or password incorrect, please try again");
        }
    }
    }
    
        
        
    }        
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package create.account;

/**
 *
 * @author aayus
 */
public class Message 
{
    String returnMessage ="I have arrived";
    
    public String getMessage()
    {
        return returnMessage;
    }
    
}

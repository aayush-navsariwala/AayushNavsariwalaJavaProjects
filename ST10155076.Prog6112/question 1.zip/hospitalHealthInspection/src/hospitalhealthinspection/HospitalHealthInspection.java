
package hospitalhealthinspection;

import java.text.DecimalFormat;


public class HospitalHealthInspection {

private static final DecimalFormat df = new DecimalFormat("0.00");

    public static void main(String[] args) {
         //Declaring 2d Array for number of inspections
        int[][] numInspection = {{4, 8, 6},
                                 {5, 4, 2},
                                 {4, 2, 8},
                                         };
        //Declaring array for hospitals
        String[] hospital = {"Hospital 1", "Hospital 2", "Hospital 3"};        

        
        double monthlyTotal = 0, sum = 0;

        
        //Generating out put for header 
        System.out.println("****************************************************************************");
        System.out.println("HEALTH INSPECTION REPORT");
        System.out.println("****************************************************************************");
        
        //Displaying the months
        System.out.println("\t\t\tJAN\t\t" + "FEB\t\t" + "MAR\t\t" + "AVG");
        
        //Loop to display phone types and sales per month and adding totals horizontally
        for(int row = 0; row < numInspection.length; row++)
        {
            System.out.print(hospital[row]);
            
            for(int col = 0; col < numInspection[row].length; col++)
            {
                sum = sum + numInspection[row][col]; // Calculates the sum of each row
                System.out.print("\t\t" +numInspection[row][col]); 
                
                
            }
            
            System.out.print("\t\t" + df.format(sum/3));
            sum = 0;
            System.out.println(" ");
            
        }
         //Displaying monthly totals
        System.out.println("****************************************************************************");
        System.out.println  ("MONTHLY TOTALS ");
        System.out.println("****************************************************************************");
        //Loop to calculate hospital totals  adding them horizontaly
         for(int row = 0; row < numInspection.length; row++)
        {
            System.out.print(hospital[row]);
            for(int col = 0; col < numInspection[row].length; col++)
            {
                monthlyTotal += numInspection[row][col]; 
            }
            System.out.print("\t\t" + monthlyTotal);
            monthlyTotal = 0;
            System.out.println(" ");
        }
       
      
        
        

    }
    
}

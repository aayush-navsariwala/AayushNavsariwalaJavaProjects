
package inspection;


import java.util.Scanner;


public class Use_Inspection {

    public static void main(String[] args) {
        // main class where the code is used
         Scanner scanner = new Scanner(System.in);
         System.out.print("Enter the hospital location: ");// prompting user for input
         String location = scanner.next();
         System.out.print("Enter the hospital name: ");// prompting user for input
         String name = scanner.next();
         System.out.print("Enter years since last inspection: ");// prompting user for input
         int years = scanner.nextInt();
        
        
        HospitalInspections hospitalInspections = new HospitalInspections(name, location, years);
        hospitalInspections.printInspectionReport();// code for displaying report of data inputted
    }
    
}




package inspection;


public abstract class Inspection implements iInspection{
    // declaring the varibales
    public String hospitalName;
    public String hospitalLocation;
    public int yearsSinceInspection;
    
    public Inspection(String hospitalName , String hospitalLocation, int yearsSinceInspection){
      this.hospitalName = hospitalName;
      this.hospitalLocation = hospitalLocation;
      this.yearsSinceInspection = yearsSinceInspection;
    }
    
    @Override
    public String getHospitalName(){// asking for hospital name
        return hospitalName;
    }

    @Override
    public String getLocation(){// asking for hospital locaation
        return hospitalLocation;
    }
    
    @Override
    public int getYearsSinceInspection(){//asking for years since inspection
        return yearsSinceInspection;
    }
    
}

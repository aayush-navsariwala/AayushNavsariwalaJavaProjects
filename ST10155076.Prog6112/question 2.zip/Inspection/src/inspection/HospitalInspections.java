
package inspection;

public class HospitalInspections extends Inspection{
       
    public HospitalInspections(String hospitalName , String hospitalLocation, int yearsSinceInspection){
      super(hospitalName, hospitalLocation,yearsSinceInspection); 
    }
    
    @Override
    public String getHospitalName(){
        return hospitalName;// askes the user for a hospital name
    }

    @Override
    public String getLocation(){
        return hospitalLocation;// asks the user for the location of the hospital
    }
    
    @Override
    public int getYearsSinceInspection(){
        return yearsSinceInspection;// asks the user how many years since an inspection was done on the hospital
    }
    
    @Override
     public String getInspectionNeeded(){
         if(getYearsSinceInspection()>2){// code for telling the user if another inspection is needed based on thier input
             return "YES";
         }
        return "NO";
    }
    public void printInspectionReport(){  
    System.out.println("HOSPITAL INSPECTION REPORT");
    System.out.println("*******************");
    System.out.println("HOSPITAL LOCATION: " + getLocation());
    System.out.println("HOSPITAL NAME : " + getHospitalName());
    System.out.println("YEARS SINCE INSPECTION: " + getYearsSinceInspection());
    System.out.println("INSPECTION NEEDED: " + getInspectionNeeded());
    // printed report 
    }
}
